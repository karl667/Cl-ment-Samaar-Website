//Merci à Mathias Boulay pour ce JavaScript
var StyleChanged=window.localStorage.getItem('StyleChanged');
console.log(StyleChanged);

if (StyleChanged !=null)
{

    if (StyleChanged==='true')
    {

        let PageStylePath=document.getElementById('linkcss').getAttribute('href');
        document.getElementById('linkcss').setAttribute('href',PageStylePath.replace('PageStyle1.css','PageStyle2.css'));

    }
}

function ChangePageStyle(){
    const linkcss=document.getElementById('linkcss');
    const PageStylePath=linkcss.getAttribute('href');

    if (PageStylePath.endsWith('PageStyle1.css'))
    {
        linkcss.setAttribute('href', PageStylePath.replace('PageStyle1.css','PageStyle2.css'));
        window.localStorage.setItem('StyleChanged','true');
        return;
    }
    linkcss.setAttribute('href', PageStylePath.replace('PageStyle2.css','PageStyle1.css'));
    window.localStorage.setItem('StyleChanged','false');
}